var axios = require('axios');
var FormData = require('form-data');
var fs = require('fs');
var data = new FormData();

module.exports = function (RED) {
	function spfJson(config) {
		RED.nodes.createNode(this, config);
		var node = this;
		node.on('input', function (msg) {
			//
			data.append('filename', fs.createReadStream(msg.payload));
			//
			var ns_config = {
				method: 'post',
				// url: 'https://ifcserver.azurewebsites.net/api/utf-8-ifc-stp-to-ifc-json',
				url: 'http://127.0.0.1:8000/api/utf-8-ifc-stp-to-ifc-json',
				headers: {
					...data.getHeaders(),
				},
				data: data,
			};
			//
			axios(ns_config)
				.then((response) => {
					msg.payload = JSON.stringify(response.data);
					node.send(msg);
				})
				.catch((error) => {
					msg.payload = error;
					node.send(msg);
				});
			//
		});
	}
	RED.nodes.registerType('spfJson', spfJson);
};
