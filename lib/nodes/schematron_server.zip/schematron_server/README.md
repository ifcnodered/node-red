---
  - Implemented website 
  - https://schematron.herokuapp.com/
---
page_type: rest-api
description: 'A rest-api to generate & validate building data using schematron, app built with Python-Flask, react deployed to Azure App Service on Linux.'
languages:
  - python
  - javascript
products:
  - azure
  - azure-app-service
---

# RestAPI using Python/Azure (Linux)

This is a Rest API Flask app that is deployed to Azure App Service on Linux.

## Contributing

More to come...
